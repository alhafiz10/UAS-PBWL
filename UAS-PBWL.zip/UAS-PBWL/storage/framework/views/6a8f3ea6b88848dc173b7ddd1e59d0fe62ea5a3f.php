<?php $__env->startSection('content'); ?>
    <div class="container">

        <h3>Tambah Data Pisang Akbar</h3>
        <form action="<?php echo e(url('/pisang')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label>KODE</label>
                <input type="text" class="form-control" name="pis_kode">
            </div>
            <div class="mb-3">
                <label>JENIS PISANG</label>
                <input type="text" class="form-control" name="pis_nama">
            </div>
            <div class="mb-3">
                <input type="submit" value="SIMPAN" class="btn btn-success">
                <a href="<?php echo e(url('pisang/')); ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UAS-PBWL-AdamDM\resources\views/pisang/create.blade.php ENDPATH**/ ?>