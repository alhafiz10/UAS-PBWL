<?php $__env->startSection('content'); ?>
    <div class="container">

        <h3>Edit Data Pelanggan</h3>
        <form action="<?php echo e(url('/pelanggan/' . $row->pel_id)); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label>NOMOR PELANGGAN</label>
                    <input type="text" class="form-control" name="pel_no" value="<?php echo e($row->pel_no); ?>"></>
                </div>
                <div class="mb-3">
                    <label>NAMA PELANGGAN</label>
                    <input type="text" class="form-control" name="pel_nama" value="<?php echo e($row->pel_nama); ?>"></>
                </div>
                <div class="mb-3">
                    <label>ALAMAT</label>
                    <input type="text" class="form-control" name="pel_alamat" value="<?php echo e($row->pel_alamat); ?>"></>
                </div>
                <div class="mb-3">
                    <label>NO HP</label>
                    <input type="text" class="form-control" name="pel_hp" value="<?php echo e($row->pel_hp); ?>"></>
                </div>
                <div class="mb-3">
                    <label>JUMLAH PELANGGAN TETAP</label>
                    <input type="text" class="form-control" name="pel_tetap" value="<?php echo e($row->pel_tetap); ?>"></>
                </div>
                <div class="mb-3">
                    <input type="submit" value="UPDATE" class="btn btn-success">
                    <a href="<?php echo e(url('pelanggan/')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UAS-PBWL-AdamDM--\UAS-PBWL\resources\views/pelanggan/edit.blade.php ENDPATH**/ ?>