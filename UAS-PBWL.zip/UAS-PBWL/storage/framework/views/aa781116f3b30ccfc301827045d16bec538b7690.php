<?php $__env->startSection('content'); ?>
    <div class="container">

        <h3>Tambah Data Pelanggan Akbar</h3>
        <form action="<?php echo e(url('/pelanggan')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label>NOMOR PELANGGAN</label>
                <input type="text" class="form-control" name="pel_no">
            </div>
            <div class="mb-3">
                <label>NAMA PELANGGAN</label>
                <input type="text" class="form-control" name="pel_nama">
            </div>
            <div class="mb-3">
                <label>ALAMAT</label>
                <input type="text" class="form-control" name="pel_alamat">
            </div>
            <div class="mb-3">
                <label>NO HP</label>
                <input type="text" class="form-control" name="pel_hp">
            </div>
            <div class="mb-3">
                <label>JUMLAH TETAP</label>
                <input type="text" class="form-control" name="pel_tetap">
            </div>
            <div class="mb-3">
                <input type="submit" value="SIMPAN" class="btn btn-success">
                <a href="<?php echo e(url('pelanggan/')); ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UAS-PBWL-AdamDM--\UAS-PBWL\resources\views/pelanggan/create.blade.php ENDPATH**/ ?>