<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(asset('images/Pisang.jpg')); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title">Akbar Alhafiz (0702193176)</h5>
                            <p class="card-text justify">Saya adalah seorang mahasiswa dari Universitas Islam Negeri Sumatera Utara saat Jurusan Sistem Informasi, saat ini saya berada di Semester 6.</p>
                            <a href="#" class="btn btn-primary">Selebihnya</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
	
        



    
<br>
    <p class="text-sian text-center mt-5">Copyright &copy; <?php if(date('Y') == '2022'): ?>  - 2025  <?php endif; ?> All rights reserved </i> by <a href="https://github.com/" target="_blank">BERBAGI.COM</a>.</p>
</div>
<?php $__env->stopSection(); ?>

    
	 


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UAS-PBWL-AdamDM--\UAS-PBWL\resources\views/home.blade.php ENDPATH**/ ?>