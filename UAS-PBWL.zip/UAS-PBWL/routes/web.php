<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

//Pisang
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/pisang', [App\Http\Controllers\PisangController::class, 'index']);
Route::get('/pisang/create', [App\Http\Controllers\PisangController::class, 'create']);
Route::post('/pisang', [App\Http\Controllers\PisangController::class, 'store']);
Route::get('/pisang/{id}/edit', [App\Http\Controllers\PisangController::class, 'edit']);
Route::patch('/pisang/{id}', [App\Http\Controllers\PisangController::class, 'update']);
Route::delete('/pisang/{id}', [App\Http\Controllers\PisangController::class, 'destroy']);

//Pelanggan

Route::get('/pelanggan', [App\Http\Controllers\PelangganController::class, 'index']);
Route::get('/pelanggan/create', [App\Http\Controllers\PelangganController::class, 'create']);
Route::post('/pelanggan', [App\Http\Controllers\PelangganController::class, 'store']);
Route::get('/pelanggan/{id}/edit', [App\Http\Controllers\PelangganController::class, 'edit']);
Route::patch('/pelanggan/{id}', [App\Http\Controllers\PelangganController::class, 'update']);
Route::delete('/pelanggan/{id}', [App\Http\Controllers\PelangganController::class, 'destroy']);