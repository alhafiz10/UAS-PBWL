@extends('layouts.app')

@section('content')
<h3>Data Pisang Akbar
    <a class="btn btn-primary btn-sm float-end" href="{{ url('/pisang/create') }}">Tambah Data</a>
</h3>

<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <th>KODE</th>
        <th>JENIS PISANG</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    @foreach ($rows as $row )
    <tr>
        <td>{{ $row->pis_id }}</td>
        <td>{{ $row->pis_kode }}</td>
        <td>{{ $row->pis_nama }}</td>
        <td><a href="{{ url('pisang/' . $row->pis_id . '/edit') }}" class="btn btn-warning">EDIT</a></td>
        <td>
            <form action="{{ url('pisang/' . $row->pis_id) }}" method="POST">
                @method('DELETE')
                @csrf
                <button type="button" class="btn btn-danger">DELETE</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>
    
   
@endsection
 