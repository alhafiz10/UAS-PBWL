@extends('Layouts.app')

@section('content')
    <div class="container">

        <h3>Tambah Data Pisang</h3>
        <form action="{{ url('/pisang') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label>KODE</label>
                <input type="text" class="form-control" name="pis_kode">
            </div>
            <div class="mb-3">
                <label>JENIS PISANG</label>
                <input type="text" class="form-control" name="pis_nama">
            </div>
            <div class="mb-3">
                <input type="submit" value="SIMPAN" class="btn btn-success">
                <a href="{{ url('pisang/') }}" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
</div>
@endsection